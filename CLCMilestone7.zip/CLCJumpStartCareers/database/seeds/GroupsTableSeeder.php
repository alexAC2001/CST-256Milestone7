<?php

use App\Group;

use Illuminate\Database\Seeder;


class GroupsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $group = Group::where('groupTitle', 'Programming')->first();
    
        if(!$group) {
            Group::create([            
                'groupTitle'=>'Programming',                    
                'about'=>'Our purpose is to help programmers progress in their career by having providing links to internships and job opportunities. Programmers in this group can also connect with each other and ask questions related to interviews and coding in general',
                'rules'=>'Bullying will not be tolerated',                    
                'members'=>null
            ]);            
        }
    }
}
