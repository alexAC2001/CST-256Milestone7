<?php 

// Alexander Carrillo & Jeanna Benitez

// CST - 256

// Apr. 16th, 2021

// This assignment was completed in collaboration with Alexander Carrillo and Jeanna Benitez

// We used source code from the following websites to complete this assignment:
// https://www.youtube.com/watch?v=Mh7DTsveHsk&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=42
// https://www.youtube.com/watch?v=Ds7rntR5E64&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=43
// https://www.youtube.com/watch?v=yyHeqTZEINU&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=44
// https://www.youtube.com/watch?v=EVogGlakwco&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=53
// https://www.youtube.com/watch?v=4JzcG8raixA&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=54
// https://www.youtube.com/watch?v=I73qqDzTwYM&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=55
// https://www.youtube.com/watch?v=U2MEGrYquk4&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=56
// https://www.youtube.com/watch?v=rTMifLFvx5A&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=57
// https://www.youtube.com/watch?v=7JLciMyI6Rs&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=58

?>

<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Laravel') }}</title>

    <!-- Scripts -->


    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    
    @yield('css')
    
</head>
<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
            <div class="container">
                <a class="navbar-brand" href="{{ url('/home') }}">
                    <img src="JSC.png" alt="Logo" width="70" height="70">
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="{{ __('Toggle navigation') }}">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">

                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        <!-- If you're a guest -->
                        @guest
                            <li class="nav-item">
                                <a class="nav-link" href="{{ route('login') }}">{{ __('Login') }}</a>
                            </li>
                            @if (Route::has('register'))
                                <li class="nav-item">
                                    <a class="nav-link" href="{{ route('register') }}">{{ __('Register') }}</a>
                                </li>
                            @endif
                        @else
                        <!-- If you're an Administrator -->
                                @if(auth()->user()->isAdmin())
                                	
                                <div style="text-align: center">
                                <form action="{{ route('users.index') }}" method="GET">
						    	
						    	@csrf
						    	
						    	<button type="submit" class="btn btn-outline-danger btn-sn ml-3">Users</button>
						    	
						    	</form> </div>
						    	
						    	<div style="text-align: center">
						    	<form action="{{ route('jobs.index') }}" method="GET">
						    	
						    	@csrf
						    	
						    	<button type="submit" class="btn btn-outline-danger btn-sn ml-3">Job Postings</button>
						    	
						    	</form></div>
						    	
						    	<form action="{{ route('discussions.index') }}" method="GET">
						    	
						    	@csrf
						    	
						    	<button type="submit" class="btn btn-outline-danger btn-sn ml-3">Affinity Groups</button>
						    	
						    	</form>
                                    
                            		@endif
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    {{ Auth::user()->name }} <span class="caret"></span>
                                </a>

                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                      
                                      <a class="dropdown-item" href="{{ route('home') }}">
                                       
                                       Home
                                    
                                    </a>
                                      
                                      <a class="dropdown-item" href="{{ route('users.edit-profile') }}">
                                       
                                       My Profile
                                    
                                    </a>
                                    
                                    <a class="dropdown-item" href="{{ route('jobs.list') }}">
                                       
                                       Jobs
                                    
                                    </a>
                                    
                                    <a class="dropdown-item" href="{{ route('searchJob') }}">
                                       
                                       Search Jobs
                                    
                                    </a>
                                    
                                    <a class="dropdown-item" href="{{ route('users.portfolio') }}">
                                       
                                       E-Portfolio
                                    
                                    </a>
                                    
                                    <a class="dropdown-item" href="{{ route('otherPortfolios') }}">
                                       
                                       View other E-Portfolios
                                    
                                    </a>
                                    
                                     <a class="dropdown-item" href="{{ route('discussions.index') }}">
                                       
                                       Affinity Groups
                                    
                                    </a>
                                                                        
                                    <a class="dropdown-item" href="{{ route('logout') }}"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        {{ __('Logout') }}
                                    </a>
                                    
                                  

                                    <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                        @csrf
                                    </form>
                                </div>
                            </li>                               
                        @endguest                        
                    </ul>
                </div>
            </div>
        </nav>
        @auth
         <!-- If you're an Administrator -->
           @if(auth()->user()->isAdmin())
        	<main class="container py-4">
        	
        		<div class="row">
        		
        			<div class="col-md-4">
        			
        				<a href="{{ route('discussions.create') }}" style="width: 100%; color: #fff"class="btn btn-info my-2">Add Group Forum</a>
        		
        					<div class="card">
        				
        						<div class="card-header">
        				
            						For Admins only
            				
            					</div>
            					
            					<div class="card-body">
            		
                            		<ul class="list-group">
                            		
                            			Click the button above to add a Group Forum for
                            			users to collaborate in different subjects.
                            		
                            		</ul>
                            		
                            	</div>
            		
            				</div>
            			
            		</div>            		
            		@endif
            		
                    <!-- If you're an normal user -->
           @if(!auth()->user()->isAdmin())
        	<main class="container py-4">
        	
        		<div class="row">
        		
        			<div class="col-md-4">
        			
        					<div class="card">
        				
        						<div class="card-header">
        				
            						Group Forums
            				
            					</div>
            					
            					<div class="card-body">
            		
                            		<ul class="list-group">
                            		
                            			Hello! Here is the Groups page 
                            			where users can enter different group chats and talk about
                            			a variety of topics. Click the View button on a Group to connect with others.
                            		
                            		</ul>
                            		
                            	</div>
            		
            				</div>
            			
            		</div>
            		
            		@endif
            		
            		
            		
            		
            		<div class="col-md-8">
            		
            			@yield('content')
            		
            		</div>
        		
        		</div>            	
            
            </main>
        
        @else
        
            <main class="py-4">
            
            	@yield('content')
            
            </main>
        
        @endauth
    </div>
    
    
        <!-- Scripts -->
        
    <script src="{{ asset('js/app.js') }}"></script>
    
    @yield('js')
    
</body>
</html>