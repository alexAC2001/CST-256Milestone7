<?php
// Alexander Carrillo & Jeanna Benitez

// CST - 256

// Apr. 16th, 2021

// This assignment was completed in collaboration with Alexander Carrillo and Jeanna Benitez

// We used source code from the following websites to complete this assignment:
// https://www.youtube.com/watch?v=Mh7DTsveHsk&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=42
// https://www.youtube.com/watch?v=Ds7rntR5E64&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=43
// https://www.youtube.com/watch?v=yyHeqTZEINU&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=44
// https://www.youtube.com/watch?v=EVogGlakwco&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=53
// https://www.youtube.com/watch?v=4JzcG8raixA&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=54
// https://www.youtube.com/watch?v=I73qqDzTwYM&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=55
// https://www.youtube.com/watch?v=U2MEGrYquk4&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=56
// https://www.youtube.com/watch?v=rTMifLFvx5A&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=57
// https://www.youtube.com/watch?v=7JLciMyI6Rs&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=58
?>
@extends('layouts.app')
<style>
            html, body {
                background-image: linear-gradient(lightskyblue, powderblue);
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }</style>
@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Search for Jobs') }}</div>

                <div class="card-body">
                    <form method="GET" action= "{{ route('searchResults') }}">
                        @csrf

                        <div class="form-group row">
                            <label for="searchJob" class="col-md-4 col-form-label text-md-right">{{ __('Job Title') }}</label>

                            <div class="col-md-6">
                                <input id="searchForJob" type="text" class="form-control @error('searchForJob') is-invalid @enderror" name="searchForJob" value="{{ old('searchForJob') }}" required autocomplete="searchForJob" autofocus>

                                @error('searchJob')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                            
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    {{ __('Search') }}
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
