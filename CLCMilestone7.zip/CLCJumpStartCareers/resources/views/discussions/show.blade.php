<?php

// Alexander Carrillo & Jeanna Benitez

// CST - 256

// Apr. 16th, 2021

// This assignment was completed in collaboration with Alexander Carrillo and Jeanna Benitez

// We used source code from the following websites to complete this assignment:
// https://www.youtube.com/watch?v=Mh7DTsveHsk&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=42
// https://www.youtube.com/watch?v=Ds7rntR5E64&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=43
// https://www.youtube.com/watch?v=yyHeqTZEINU&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=44
// https://www.youtube.com/watch?v=EVogGlakwco&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=53
// https://www.youtube.com/watch?v=4JzcG8raixA&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=54
// https://www.youtube.com/watch?v=I73qqDzTwYM&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=55
// https://www.youtube.com/watch?v=U2MEGrYquk4&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=56
// https://www.youtube.com/watch?v=rTMifLFvx5A&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=57
// https://www.youtube.com/watch?v=7JLciMyI6Rs&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=58


// This is to show the replies in a group discussion

?>

@extends('layouts.groups')
<style>
            html, body {
                background-image: linear-gradient(lightskyblue, powderblue);
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }</style>
            
          
            
@section('content')

	
	<div class="card">
		
		<div class="card-header">			
			
			<div class="d-flex justify-content-between">
			
				<div>
						
				<strong class="ml-2">{{ $discussion->author->name }}</strong>
			
				</div>
				
				<div>
				
					<a href="{{ route('discussions.show', $discussion->slug) }}"  class="btn btn-success btn-sm">View</a>
				
				</div>
			
			</div>
					
		</div>
	
		<div class="card-body">
		
			{{ $discussion->title }}
			
			<hr>
		
		
			{!! $discussion->content !!}
		</div>
	
	</div>
	
	@foreach($discussion->replies()->paginate(3) as $reply)
	
    	<div class="card my-5">
    	
        	<div class="card-header">
        	
            	<div class="d-flex justify-content-between">
            	
                	<div>
                	
                		<span>{{ $reply->owner->name }}</span>
                	
                	</div>
                	
                </div> 
        	
        	</div>
        	
        	<div class="card-body">
        	
        	{!! $reply->content !!}
        	
        	</div>
        	
    	</div>
	
	@endforeach
	
	{{ $discussion->replies()->paginate(3)->links() }}
	
	<div class="card my-5">
	
		<div class="card-body">
		
			Add a Reply
		
		</div>
		
		<div class="card-body">
		
		@auth
		
			<form action="{{ route('replies.store', $discussion->slug) }}" method="POST">
			
				@csrf
				
				<input type="hidden" name="content" id="content">
				
				<trix-editor input="content"></trix-editor>
			
				<button type="submit" class="btn btn-sm my-2 btn-success">
				
					Add Reply
				
				</button>
			
			
			</form>			
		
		@else
		
		You must be signed in to reply
		
		@endauth
		
		</div>
	
	</div>

@endsection

@section('css')

	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/trix/1.0.0/trix.css">

@endsection

@section('js')

	<script src="https://cdnjs.cloudflare.com/ajax/libs/trix/1.0.0/trix.js"></script>
	
@endsection
