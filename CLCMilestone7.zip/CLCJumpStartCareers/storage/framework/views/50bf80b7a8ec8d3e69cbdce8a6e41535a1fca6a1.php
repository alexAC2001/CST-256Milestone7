<?php

// Alexander Carrillo & Jeanna Benitez

// CST - 256

// Feb. 7th, 2021

// This assignment was completed in collaboration with Alexander Carrillo and Jeanna Benitez

// We used source code from the following websites to complete this assignment:
// https://www.youtube.com/watch?v=Mh7DTsveHsk&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=42
// https://www.youtube.com/watch?v=Ds7rntR5E64&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=43
// https://www.youtube.com/watch?v=yyHeqTZEINU&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=44

?>


<style>
            html, body {
                background-image: linear-gradient(lightskyblue, powderblue);
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }</style>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Update Job</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

								

                    <form action="<?php echo e(route('jobs.update', $job->id)); ?>" method="POST">
                    
                    <?php echo csrf_field(); ?>
                    
                    <?php echo method_field('PUT'); ?>
                    
                    <div class="form-group">
                    
                    	<label for="jobTitle">Job Title</label>
                    
                    	<input type="text" class="form-control" name="jobTitle" id="jobTitle" value="<?php echo e($job->jobTitle); ?>">
                    
                    </div>
                    
                    <div class="form-group">
                    
                    	<label for="companyName">Company Name</label>
                    
                    	<input type="text" class="form-control" name="companyName" id="companyName" value="<?php echo e($job->companyName); ?>">
                    
                    </div>
                    
                    <div class="form-group">
                    
                    	<label for="jobDescription">Job Description</label>
                    
                    	<input type="text" class="form-control" name="jobDescription" id="jobDescription" value="<?php echo e($job->jobDescription); ?>">
                    
                    </div>
                    
                    <div class="form-group">
                    
                    	<label for="jobLocation">Job Location</label>
                    
                    	<input type="text" class="form-control" name="jobLocation" id="jobLocation" value="<?php echo e($job->jobLocation); ?>">
                    
                    </div>
                    <div class="form-group">
                    
                    	<label for="employmentType">Employment Type</label>
                    
                    	<input type="text" class="form-control" name="employmentType" id="employmentType" value="<?php echo e($job->employmentType); ?>">
                    
                    </div>
                    
                    <button type="submit" class="btn btn-success">Update</button>
                    
                    </form>                    
                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MAMP\htdocs\CLCMilestone6\resources\views/jobs/edit.blade.php ENDPATH**/ ?>