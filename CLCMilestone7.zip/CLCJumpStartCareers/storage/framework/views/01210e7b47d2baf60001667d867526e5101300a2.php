<?php

// Alexander Carrillo & Jeanna Benitez

// CST - 256

// Feb. 7th, 2021

// This assignment was completed in collaboration with Alexander Carrillo and Jeanna Benitez

// We used source code from the following websites to complete this assignment:
// https://www.youtube.com/watch?v=Mh7DTsveHsk&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=42
// https://www.youtube.com/watch?v=Ds7rntR5E64&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=43
// https://www.youtube.com/watch?v=yyHeqTZEINU&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=44


// This is the ACTUAL home page(once logged in)

?>


<style>
            html, body {
                background-image: linear-gradient(lightskyblue, powderblue);
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }</style>
            
          
            
<?php $__env->startSection('content'); ?>

	
	<div class="card">
		
		<div class="card-header">			
			
			<div class="d-flex justify-content-between">
			
				<div>
						
				<strong class="ml-2"><?php echo e($discussion->author->name); ?></strong>
			
				</div>
				
				<div>
				
					<a href="<?php echo e(route('discussions.show', $discussion->slug)); ?>"  class="btn btn-success btn-sm">View</a>
				
				</div>
			
			</div>
					
		</div>
	
		<div class="card-body">
		
			<?php echo e($discussion->title); ?>

			
			<hr>
		
		
			<?php echo $discussion->content; ?>

		</div>
	
	</div>
	
	<?php $__currentLoopData = $discussion->replies()->paginate(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	
    	<div class="card my-5">
    	
        	<div class="card-header">
        	
            	<div class="d-flex justify-content-between">
            	
                	<div>
                	
                		<span><?php echo e($reply->owner->name); ?></span>
                	
                	</div>
                	
                </div> 
        	
        	</div>
        	
        	<div class="card-body">
        	
        	<?php echo $reply->content; ?>

        	
        	</div>
        	
    	</div>
	
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	
	<?php echo e($discussion->replies()->paginate(3)->links()); ?>

	
	<div class="card my-5">
	
		<div class="card-body">
		
			Add a Reply
		
		</div>
		
		<div class="card-body">
		
		<?php if(auth()->guard()->check()): ?>
		
			<form action="<?php echo e(route('replies.store', $discussion->slug)); ?>" method="POST">
			
				<?php echo csrf_field(); ?>
				
				<input type="hidden" name="content" id="content">
				
				<trix-editor input="content"></trix-editor>
			
				<button type="submit" class="btn btn-sm my-2 btn-success">
				
					Add Reply
				
				</button>
			
			
			</form>			
		
		<?php else: ?>
		
		You must be signed in to reply
		
		<?php endif; ?>
		
		</div>
	
	</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/trix/1.0.0/trix.css">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

	<script src="https://cdnjs.cloudflare.com/ajax/libs/trix/1.0.0/trix.js"></script>
	
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.groups', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MAMP\htdocs\CLCMilestone6\resources\views/discussions/show.blade.php ENDPATH**/ ?>