<div class="card-header">			
			
	<div class="d-flex justify-content-between">
	
		<div>
				
		<strong class="ml-2"><?php echo e($discussion->author->name); ?></strong>
	
		</div>
		
		<div>
		
			<a href="<?php echo e(route('discussions.show', $discussion->slug)); ?>"  class="btn btn-success btn-sm">View</a>
		
		</div>
	
	</div>
			
</div><?php /**PATH C:\MAMP\htdocs\CLCMilestone6\resources\views/partials/discussion-header.blade.php ENDPATH**/ ?>