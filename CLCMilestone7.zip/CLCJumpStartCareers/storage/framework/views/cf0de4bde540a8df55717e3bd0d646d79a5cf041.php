<?php
// Alexander Carrillo & Jeanna Benitez

// CST - 256

// March 11th, 2021

// This assignment was completed in collaboration with Alexander Carrillo and Jeanna Benitez

// We used source code from the following websites to complete this assignment:
// https://www.w3schools.com/css/tryit.asp?filename=trycss3_gradient-linear
// https://www.tutorialspoint.com/How-to-set-Text-alignment-in-HTML#:~:text=To%20set%20text%20alignment%20in%20HTML%2C%20use%20the%20style%20attribute,center%2C%20left%20and%20right%20alignment.
// https://www.w3schools.com/tags/tryit.asp?filename=tryhtml5_global_class2
?>

<style>
            html, body {
                background-image: linear-gradient(lightskyblue, powderblue);
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }</style>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Search for Jobs')); ?></div>

                <div class="card-body">
                    <form method="GET" action= "<?php echo e(route('searchResults')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="searchJob" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Job Title')); ?></label>

                            <div class="col-md-6">
                                <input id="searchForJob" type="text" class="form-control <?php if ($errors->has('searchForJob')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('searchForJob'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="searchForJob" value="<?php echo e(old('searchForJob')); ?>" required autocomplete="searchForJob" autofocus>

                                <?php if ($errors->has('searchJob')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('searchJob'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                            
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Search')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MAMP\htdocs\CLCMilestone6\resources\views/jobs/searchJob.blade.php ENDPATH**/ ?>