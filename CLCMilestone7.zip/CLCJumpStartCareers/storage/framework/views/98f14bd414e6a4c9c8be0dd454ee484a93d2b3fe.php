<html>
	<input type="file" name="image">
</html><?php /**PATH C:\MAMP\htdocs\CLCMilestone6\resources\views/layouts/image.blade.php ENDPATH**/ ?>