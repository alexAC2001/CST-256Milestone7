<?php 
// Alexander Carrillo & Jeanna Benitez

// CST - 256

// January 24th, 2021

// This assignment was completed in collaboration with Alexander Carrillo and Jeanna Benitez

// We used source code from the following websites to complete this assignment:
// https://www.w3schools.com/css/tryit.asp?filename=trycss3_gradient-linear
// https://www.tutorialspoint.com/How-to-set-Text-alignment-in-HTML#:~:text=To%20set%20text%20alignment%20in%20HTML%2C%20use%20the%20style%20attribute,center%2C%20left%20and%20right%20alignment.
// https://www.w3schools.com/tags/tryit.asp?filename=tryhtml5_global_class2
?>

<style>
            html, body {
                background-image: linear-gradient(lightskyblue, powderblue);
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }</style>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Post New Job')); ?></div>

                <div class="card-body">
                    <form method="POST" action= "<?php echo e(route('jobs.index')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="jobTitle" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Job Title')); ?></label>

                            <div class="col-md-6">
                                <input id="jobTitle" type="text" class="form-control <?php if ($errors->has('jobTitle')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('jobTitle'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="jobTitle" value="<?php echo e(old('jobTitle')); ?>" required autocomplete="jobTitle" autofocus>

                                <?php if ($errors->has('jobTitle')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('jobTitle'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="companyName" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Company Name')); ?></label>

                            <div class="col-md-6">
                                <input id="companyName" type="text" class="form-control <?php if ($errors->has('companyName')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('companyName'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="companyName" value="<?php echo e(old('companyName')); ?>" required autocomplete="companyName">

                                <?php if ($errors->has('companyName')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('companyName'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                        
                        <div class="form-group row">
                            <label for="companyName" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Job Description')); ?></label>

                            <div class="col-md-6">
                                <input id="jobDescription" type="text" class="form-control <?php if ($errors->has('jobDescription')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('jobDescription'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="jobDescription" value="<?php echo e(old('jobDescription')); ?>" required autocomplete="jobDescription">

                                <?php if ($errors->has('jobDescription')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('jobDescription'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="jobLocation" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Job Location')); ?></label>

                            <div class="col-md-6">
                                <input id="jobLocation" type="text" class="form-control <?php if ($errors->has('jobLocation')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('jobLocation'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="jobLocation" required autocomplete="jobLocation">

                                <?php if ($errors->has('jobLocation')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('jobLocation'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                        
                        <div class="form-group row">
                            <label for="employmentType" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Employment Type')); ?></label>

                            <div class="col-md-6">
                                <input id="employmentType" type="text" class="form-control <?php if ($errors->has('employmentType')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('employmentType'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="employmentType" required autocomplete="employmentType">

                                <?php if ($errors->has('employmentType')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('employmentType'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>


                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Post Job')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MAMP\htdocs\CLCMilestone6\resources\views/jobs/create.blade.php ENDPATH**/ ?>