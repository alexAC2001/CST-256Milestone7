<?php

// Alexander Carrillo & Jeanna Benitez

// CST - 256

// Apr. 16th, 2021

// This assignment was completed in collaboration with Alexander Carrillo and Jeanna Benitez

// We used source code from the following websites to complete this assignment:
// https://www.youtube.com/watch?v=Mh7DTsveHsk&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=42
// https://www.youtube.com/watch?v=Ds7rntR5E64&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=43
// https://www.youtube.com/watch?v=yyHeqTZEINU&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=44
// https://www.youtube.com/watch?v=EVogGlakwco&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=53
// https://www.youtube.com/watch?v=4JzcG8raixA&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=54
// https://www.youtube.com/watch?v=I73qqDzTwYM&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=55
// https://www.youtube.com/watch?v=U2MEGrYquk4&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=56
// https://www.youtube.com/watch?v=rTMifLFvx5A&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=57
// https://www.youtube.com/watch?v=7JLciMyI6Rs&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=58

namespace App\Http\Controllers;

use App\Job;
use App\User;
use App\Http\Requests\Users\UpdateProfileRequest;
use App\Http\Requests\Jobs\UpdateJobRequest;

use Illuminate\Contracts\Validation\Validator;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;


    
class JobsController extends Controller
{

    
    // This method DISPLAYS a page with all the users for the admin
    public function index()
    {
        return view('users.index')->with('users', User::all());       
    }
    
    // To DISPLAY all job posting for and Admin
    public function jobs()
    {
        return view('jobs.index')->with('jobs', Job::all());
    }
    // To DISPLAY all jobs for anyone to see
    public function list()
    {
        return view('jobs.list')->with('jobs', Job::all());
    }
    
    public function show(Job $id)
    {
        return view('jobs.index', ['job'=>id]);
    }
    public function create()
    {
        return view('jobs.create');
    }
    public function store()
    {
        $job = new Job;
        
        $job->jobTitle = request('jobTitle');
        $job->companyName = request('companyName');
        $job->jobDescription = request('jobDescription');
        $job->jobLocation = request('jobLocation');
        $job->employmentType = request('employmentType');
        $job->applicants = request('applicants');
        $job->save();
        return Redirect::back();
    }
    
    public function edit($id)
    {
        // get the job
        $job = job::find($id);
        
        // show the eidt form and pass the job
        return view('jobs.edit')->with('job', $job);
    }
    
    public function update($id)
    {
        // validate
        // read more on validation at http://laravel.com/docs/validation
        $rules = array(
            'jobTitle'       => 'required',
            'companyName'      => 'required|companyName',
            'jobDescription'      => 'required|jobDescription',
            'jobLocation' => 'required|jobLocation',
            'employmentType' => 'required|employmentType'
        );
       /* $validator = Validator::make(Input::all(), $rules);
        
        // process the login
        if ($validator->fails()) {
            return Redirect::to('sharks/' . $id . '/edit')
            ->withErrors($validator)
            ->withInput(Input::except('password'));
        } else {*/
            // store
            $job = job::find($id);
            $job->jobTitle       = Input::get('jobTitle');
            $job->companyName      = Input::get('companyName');
            $job->jobDescription      = Input::get('jobDescription');
            $job->jobLocation = Input::get('jobLocation');
            $job->employmentType = Input::get('employmentType');
            $job->save();
            
            // redirect
            //Session::flash('message', 'Successfully updated shark!');
            //return Redirect::to('jobs.index');
            return Redirect::back();
        //}
    }
    
    public function destroy($id)
    {
        // delete
        $job = job::find($id);
        $job->delete();
        
        // Redirect
        //Session::flash('message', 'Successfully deleted the job');
        //return Redirect::to('jobs.index');
        return Redirect::back();
    }
    
    // Return a Search Page
    public function searchPage()
    {
        return view('jobs.searchJob');
    }
    
    // Search Method
    public function search(){
        if(request()->query('search')) {
            dd(request()->query('search'));
        }
        return view('jobs.searchJob');
    }
    
    // Details Method
    public function details($id)
    {
        $job = job::find($id);
        
        // validate 
        $rules = array(
            'jobTitle'       => 'required',
            'companyName'      => 'required|companyName',
            'jobDescription'      => 'required|jobDescription',
            'jobLocation' => 'required|jobLocation',
            'employmentType' => 'required|employmentType',
            'applicants' => 'required|applicants'
        );

        return view('jobs.details')->with('job', $job);
    }
    
    // For Users/Admins to join an affinity group
    public function apply($id)
    {
        // store
        $job = job::find($id);
        $user = auth()->user();
        
        //$user = //user::find($name);
        //$group->members = Input::get('members', $user->name);
        $job->applicants = Input::get('applicants', $user->name);
        $job->save();
        // redirect
        //Session::flash('message', 'Successfully updated ');
        return redirect()->back();
    }
    
    // Search function to show the corresponding jobs
    public function searchPageHandler()
    {
        return view('jobs.searchResults')->with('jobs', Job::all());
    }    
}
