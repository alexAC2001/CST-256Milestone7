<?php

// Alexander Carrillo & Jeanna Benitez

// CST - 256

// Apr. 16th, 2021

// This assignment was completed in collaboration with Alexander Carrillo and Jeanna Benitez

// We used source code from the following websites to complete this assignment:
// https://www.youtube.com/watch?v=Mh7DTsveHsk&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=42
// https://www.youtube.com/watch?v=Ds7rntR5E64&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=43
// https://www.youtube.com/watch?v=yyHeqTZEINU&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=44
// https://www.youtube.com/watch?v=EVogGlakwco&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=53
// https://www.youtube.com/watch?v=4JzcG8raixA&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=54
// https://www.youtube.com/watch?v=I73qqDzTwYM&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=55
// https://www.youtube.com/watch?v=U2MEGrYquk4&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=56
// https://www.youtube.com/watch?v=rTMifLFvx5A&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=57
// https://www.youtube.com/watch?v=7JLciMyI6Rs&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=58

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Discussion;
use App\Http\Requests\CreateReplyRequest;

class RepliesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    // This will save the user's reply to the database
    public function store(CreateReplyRequest $request, Discussion $discussion)
    {
        
        // Save the user's reply
        auth()->user()->replies()->create([
            
            'content' => $request->content,
            
            'discussion_id' => $discussion->id
            
        ]);
        
        session()->flash('success', 'Reply added');
        
        return redirect()->back();        
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
