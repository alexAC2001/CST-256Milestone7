<?php

// Alexander Carrillo & Jeanna Benitez

// CST - 256

// Apr. 16th, 2021

// This assignment was completed in collaboration with Alexander Carrillo and Jeanna Benitez

// We used source code from the following websites to complete this assignment:
// https://www.youtube.com/watch?v=Mh7DTsveHsk&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=42
// https://www.youtube.com/watch?v=Ds7rntR5E64&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=43
// https://www.youtube.com/watch?v=yyHeqTZEINU&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=44
// https://www.youtube.com/watch?v=EVogGlakwco&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=53
// https://www.youtube.com/watch?v=4JzcG8raixA&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=54
// https://www.youtube.com/watch?v=I73qqDzTwYM&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=55
// https://www.youtube.com/watch?v=U2MEGrYquk4&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=56
// https://www.youtube.com/watch?v=rTMifLFvx5A&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=57
// https://www.youtube.com/watch?v=7JLciMyI6Rs&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=58

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Discussion;
use App\Http\Requests\CreateDiscussionRequest;
use Illuminate\Http\Resources\Json\PaginatedResourceResponse;

class DiscussionController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth')->only(['create', 'store']);
    }
    
    
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('discussions.index', [
            'discussions' => Discussion::paginate(5) // get 5 records at a time so the page does not load a lot of discussions at once
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    // Allows the admin to create a new group discussion/forum by going to the create discussions page
    public function create()
    {
        return view('discussions.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    // This will save the input values for a new group forum
    public function store(CreateDiscussionRequest $request)
    {
        auth()->user()->discussions()->create([
            'title' => $request->title,            
            'content' => $request->content,
            //'channel_id' => $request->channel,
            'slug' => str_slug($request->title)
        ]);
        
        //session()->flash('success', 'Discussion posted.');
        
        return redirect()->route('discussions.index');
        //return view('discussions.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    // This will allow the forums to be shown on the page
    public function show(Discussion $discussion)
    {
        // use slog to find discussion that's in the database
        return view('discussions.show', [
           'discussion' => $discussion 
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
